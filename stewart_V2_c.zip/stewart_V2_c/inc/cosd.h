/*
 * File: cosd.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 22-Jul-2025 17:39:51
 */

#ifndef COSD_H
#define COSD_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "stewart_control_function_V4_part_test_1_types.h"

/* Function Declarations */
extern void b_cosd(double *x);

#endif

/*
 * File trailer for cosd.h
 *
 * [EOF]
 */
