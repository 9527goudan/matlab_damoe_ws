/*
 * File: inv.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 22-Jul-2025 17:39:51
 */

#ifndef INV_H
#define INV_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "stewart_control_function_V4_part_test_1_types.h"

/* Function Declarations */
extern void inv(const double x[36], double y[36]);

#endif

/*
 * File trailer for inv.h
 *
 * [EOF]
 */
