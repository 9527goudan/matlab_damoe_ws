/*
 * File: stewart_control_function_V4_part_test_1_data.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 22-Jul-2025 17:39:51
 */

#ifndef STEWART_CONTROL_FUNCTION_V4_PART_TEST_1_DATA_H
#define STEWART_CONTROL_FUNCTION_V4_PART_TEST_1_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "stewart_control_function_V4_part_test_1_types.h"

/* Variable Declarations */
extern double pre_Pf[6];
extern double pre_length_last[6];
extern double flag_v;
extern bool isInitialized_stewart_control_function_V4_part_test_1;

#endif

/*
 * File trailer for stewart_control_function_V4_part_test_1_data.h
 *
 * [EOF]
 */
