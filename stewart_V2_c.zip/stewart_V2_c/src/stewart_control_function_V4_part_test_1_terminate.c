/*
 * File: stewart_control_function_V4_part_test_1_terminate.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 22-Jul-2025 17:39:51
 */

/* Include Files */
#include "stewart_control_function_V4_part_test_1_terminate.h"
#include "rt_nonfinite.h"
#include "stewart_control_function_V4_part_test_1.h"
#include "stewart_control_function_V4_part_test_1_data.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void stewart_control_function_V4_part_test_1_terminate(void)
{
  d_stewart_control_function_V4_p();
  isInitialized_stewart_control_function_V4_part_test_1 = false;
}

/*
 * File trailer for stewart_control_function_V4_part_test_1_terminate.c
 *
 * [EOF]
 */
