/*
 * File: stewart_control_function_V4_part_test_1_data.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 22-Jul-2025 17:39:51
 */

/* Include Files */
#include "stewart_control_function_V4_part_test_1_data.h"
#include "rt_nonfinite.h"
#include "stewart_control_function_V4_part_test_1.h"

/* Variable Definitions */
double pre_Pf[6];
double pre_length_last[6];
double flag_v;
bool isInitialized_stewart_control_function_V4_part_test_1 = false;

/*
 * File trailer for stewart_control_function_V4_part_test_1_data.c
 *
 * [EOF]
 */
